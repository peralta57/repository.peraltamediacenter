#!/usr/bin/python
# -*- coding: utf-8 -*-
import widgetFunctions

widgetFunctions.Main()
